#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <map>
using namespace std;

vector<string> readfile()					
{
	ifstream myfile("CS210_Project_Three_Input_File.txt"); //opens file

	if (!myfile.is_open())								//checks to make sure file is open
		exit(EXIT_FAILURE);


	vector<string> myVector;
	string str;


	while (myfile.good())								//iterates through file and stores in vector
	{
		myfile >> str;
		myVector.push_back(str);
	}
	myfile.close();										//closes file

return myVector;									//returns the vector with file information
} 

void menuone() //menu 1 function
{
	string item;

	cout << "Please input the item you wish to look for" << endl;          //asks for user input on the item they want to look up
	cin >> item;

	vector<string> v = readfile();											// pulls data from readfile function
	map <string, int> frequency;

	for (string item : v)													//gets item frequency
		++frequency[item];

	cout << item << " " << frequency[item] << endl;							// outputs to user the item and frequency
	
}

void menutwo()
{
	string item;
	ofstream freq("frequency.dat");					// creates file for documenting data
	vector<string> v = readfile();					//pulls readfile information
	map <string, int> frequency;

	for (string item : v)							// map and iterate through data to find frequency
		++frequency[item];
	for (const auto& e : frequency)
	{
		
		freq << e.first << " " << e.second << endl;		//stores data in new file
		cout << e.first << " " << e.second << endl;		//outputs to user list of items and frequency
	}
	freq.close();
}

void menuthree()
{
	string item;

	vector<string> v = readfile();							//pulls readfile information
	map <string, int> frequency;

	for (string item : v)								// map and iterate through data to find frequency
		++frequency[item];
	for (const auto& e : frequency) 
	{
		cout << e.first << " ";							//outputs to user list of items and frequency using asterisks to make a histogram 
		for (int i = 0; i < e.second; i++)
		{
			cout << "*";
		}
			
		cout << endl;
	}
}

void mainMenu() 
{
	int userChoice; 

	cout << "Please select the menu option you would like to use: " << endl;										//menu options
	cout << "1 - Return a numeric value for the frequency of the specific word." << endl;
	cout << "2 - Print the list with numbers that represent the frequency of all items purchased." << endl;
	cout << "3 - Print the same frequency information for all the items in the form of a histogram." << endl;
	cout << "4 - Exit program" << endl; 

	cin >> userChoice;

	switch (userChoice)						//switch cases for menu choices to call functions
	{
		case 1:
			menuone();
			break;

		case 2:
			menutwo();
			break;
		case 3: 
			menuthree();
			break; 
		case 4: 
			cout << "Program exited";
			break; 

	}




}

int main()
{
	mainMenu(); //calls menu function

}